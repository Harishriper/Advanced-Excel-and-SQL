
-----DATA  PREPARATION AND UNSDANDING PROCESS QUESTION-----
-----1Q---
SELECT COUNT(*)
FROM Customer with(nolock)

SELECT COUNT(*)
FROM Transactions   with(nolock)

SELECT COUNT(*)
FROM prod_cat_info  with(nolock)
---END 1Q-----

-----START 2Q----
SELECT COUNT(transaction_id)
from Transactions with(nolock)
where Qty<0
----end 2Q -----

---3Q START----
--IMPORRTING THE DATA---
-------END 3Q---

-----START 4Q----
select tran_date ,
 DATEPART(yy, tran_date),
 DATEPART(month, tran_date),
 DATEPART(day, tran_date) 
 FROM Transactions t 
 ----4q end------

-----START 5Q------
SELECT prod_cat
 FROM prod_cat_info  with(nolock)
 where prod_subcat = 'DIY'
 ----END  5Q------

-----START 5Q------
select top 1 Store_type, COUNT(1) 'count'
from Transactions with(nolock)
group by Store_type
order by 'count' desc

-----END1-----


-----START 2Q------
select Gender, COUNT(1) 'count'
from Customer with(nolock)
where Gender is not null
group by Gender

-----END2Q-----

-----START 3Q------.
select top 1 city_code, COUNT(1) 'customers'
from Customer with(nolock)
where city_code is not null
group by city_code
order by 'customers' desc
---END3Q-----

-- 
-----START 4Q------.
select top 1 prod_cat, COUNT(2) 'sub categoies'
from prod_cat_info q with(nolock)
where LOWER(prod_cat)='books'
group by prod_cat
order by 'sub categoies' desc
---END4Q-----

-- 5QSTART----.
select top 1 Qty 
from Transactions with(nolock)
order by Qty desc
---END5Q-----

-- 6Q START-----.
select sum(case when total_amt<0 then total_amt+Tax else total_amt-Tax end) 'net total revenue'
from Transactions t with(nolock)
inner join prod_cat_info pci with(nolock)
	on t.prod_cat_code=pci.prod_cat_code and t.prod_subcat_code=pci.prod_sub_cat_code
where lower(pci.prod_cat) in ('books', 'electronics')

---END6Q-----


-- 7Q START-----
select cust_id, COUNT(distinct transaction_id) 'count' into #cust_trans
from Transactions t with(nolock)
group by cust_id
having COUNT(distinct transaction_id)>10
order by 'count' desc;
select count(1) from #cust_trans;
DROP TABLE #cust_trans;

---END7Q-----


----
------ Q8START------ ----
select sum(total_amt) 'Revenue'
from Transactions t with(nolock)
inner join prod_cat_info pci with(nolock)
	on t.prod_cat_code=pci.prod_cat_code and t.prod_subcat_code=pci.prod_sub_cat_code
where lower(pci.prod_cat) in ('clothing' , 'electronics')
	and lower(t.Store_type)='flagship store'

	---END8Q-----

------
------ Q9 START------ ----
select pci.prod_subcat, sum(t.total_amt) 'Revenue'
from Transactions t with(nolock)
inner join Customer c with(nolock)
	on t.cust_id=c.customer_Id
inner join prod_cat_info pci with(nolock)
	on t.prod_cat_code=pci.prod_cat_code and t.prod_subcat_code=pci.prod_sub_cat_code
where c.Gender='M' and lower(pci.prod_cat) in ('electronics')
group by pci.prod_subcat 

---END9Q-----

------ Q10START------ ------

select pci.prod_subcat, sum(t.Qty) 'Sales', abs(sum(case when t.Qty<0 then t.Qty else 0 end)) 'Returns' into #sales_returns
from Transactions t with(nolock)
inner join prod_cat_info pci with(nolock)
	on t.prod_cat_code=pci.prod_cat_code and t.prod_subcat_code=pci.prod_sub_cat_code
group by pci.prod_subcat;
select top 5 sr.prod_subcat, (sr.sales*100.0)/(sr.sales+sr.returns) '%Sales', (sr.returns*100.0)/(sr.sales+sr.returns) '%Returns'
from #sales_returns sr
order by '%sales' desc;
drop table #sales_returns;

---END10Q-----



------ Q11 START------ ----

SELECT customer_Id, DOB,GETDATE() AS CURRENTDATE,DATEDIFF(YY,DOB,GETDATE()) AS AGE into #age_netTR
FROM Customer
 
SELECT  sum(case when total_amt<0 then total_amt+Tax else total_amt-Tax end) ' LAST 30 DAYS NTR'
FROM #age_netTR a
INNER JOIN Transactions t with(nolock)
on a.customer_Id = t.cust_id
WHERE (a.AGE BETWEEN 25 AND 35)
AND
DATEDIFF(day,DATEADD(day, -30, (select max(tran_date) from Transactions)),tran_date) between 0 and 30
---END11Q-----

------
------ Q12 START-----------
SELECT prod_cat,tran_date, (QTY)
FROM Transactions T with(nolock)
inner join prod_cat_info pci with(nolock)
	on t.prod_cat_code=pci.prod_cat_code
where DATEDIFF(MONTH,DATEADD(MONTH, -3, (select max(tran_date) from Transactions)),tran_date) between 0 and 3
AND Qty= (select min(Qty) as 'maximum returen'
from Transactions)
  order by prod_cat

  ---END12Q-----


-----
------ Q13 START------ ----
SELECT  top 1 STORE_TYPE,sum(total_amt) tmt,SUM(qty) as q
FROM Transactions t
group by Store_type 
order by tmt desc,q desc
---END13Q-----

--------
------ Q14 START------ -----
SElect prod_cat ,AVG(t.total_amt) as AVG_AM
from prod_cat_info pci
 INNER JOIN Transactions t with(nolock)
 on pci.prod_cat_code = t.prod_cat_code
 and pci.prod_sub_cat_code =t.prod_subcat_code
 group by prod_cat
 having AVG(t.total_amt)>(
 select AVG(total_amt)
 from Transactions)

-----Q14 END--



------ Q15 START------ 
SElect top 5 prod_subcat,AVG(t.total_amt) as AVG_AM,sum(case when total_amt<0 then total_amt+Tax else total_amt-Tax end) as total_revenue
from prod_cat_info pci
 INNER JOIN Transactions t with(nolock)
on pci.prod_sub_cat_code = t.prod_subcat_code
 group by prod_subcat



 ----end15Q----